from championship import Championship


championship = Championship()
championship.defineGrandprix("katta halqa yoli")
print(championship.getGrandPrix('katta halqa yoli'))



